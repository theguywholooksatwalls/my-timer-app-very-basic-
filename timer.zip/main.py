import tkinter as tk
from tkinter import messagebox
import webbrowser
import threading
import time

class TimerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Interactive Timer")

        self.duration_label = tk.Label(master, text="Duration (seconds):")
        self.duration_label.pack()

        self.duration_entry = tk.Entry(master)
        self.duration_entry.pack()

        self.timer_display = tk.Label(master, text="", font=("Helvetica", 48))
        self.timer_display.pack()

        self.fps_label = tk.Label(master, text="", font=("Helvetica", 12))
        self.fps_label.pack()

        self.start_button = tk.Button(master, text="Start", command=self.start_timer)
        self.start_button.pack()

        self.stop_button = tk.Button(master, text="Stop", command=self.stop_timer, state=tk.DISABLED)
        self.stop_button.pack()

        self.instagram_button = tk.Button(master, text="Visit My Instagram", command=self.visit_instagram)
        self.instagram_button.pack()

        self.remaining_time = 0
        self.timer_running = False
        self.fps_counter = 0
        self.timer_thread = None

        # Start the FPS update loop in a separate thread
        self.fps_thread = threading.Thread(target=self.update_fps)
        self.fps_thread.daemon = True
        self.fps_thread.start()

    def start_timer(self):
        try:
            duration = int(self.duration_entry.get())
            if duration <= 0:
                raise ValueError
            self.remaining_time = duration
            self.update_timer_display()
            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.timer_running = True
            self.fps_counter = 0
            self.timer_thread = threading.Thread(target=self.run_timer)
            self.timer_thread.start()
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid positive integer for duration.")

    def run_timer(self):
        start_time = time.time()
        while self.remaining_time > 0 and self.timer_running:
            self.remaining_time -= 1
            self.update_timer_display()
            time.sleep(1)
            self.fps_counter += 1
        if self.timer_running:
            messagebox.showinfo("Timer", "Time's up!")
            self.stop_timer()
        elapsed_time = time.time() - start_time
        fps = self.fps_counter / elapsed_time
        self.fps_label.config(text=f"FPS: {fps:.2f}")

    def stop_timer(self):
        self.timer_running = False
        self.start_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.timer_thread.join()

    def update_timer_display(self):
        minutes, seconds = divmod(self.remaining_time, 60)
        self.timer_display.config(text=f"{minutes:02d}:{seconds:02d}")

    def visit_instagram(self):
        webbrowser.open("https://www.instagram.com/the_guywholooks_at_walls/")  # Replace "your_username" with your actual Instagram username

    def update_fps(self):
        # Continuously update the FPS label
        while True:
            if not self.timer_running:
                fps = self.fps_counter
                self.fps_label.config(text=f"FPS: {fps}")
            time.sleep(1)

def main():
    root = tk.Tk()
    app = TimerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
